sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/ColumnListItem",
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Label',
	'sap/m/MessageToast',
	'sap/ui/layout/HorizontalLayout',
	'sap/ui/layout/VerticalLayout',
	'sap/m/TextArea',
	'sap/m/MessageBox',
	"sap/ui/model/json/JSONModel"
], function (Controller, ColumnListItem, Button, Dialog, MessageToast, Label, HorizontalLayout, VerticalLayout, TextArea, MessageBox,
	JSONModel) {
	"use strict";

	return Controller.extend("sap.uisubmit_application.controller.Home", {
		serviceUrl: null,
		siteID: null,
		currentPage: 0,
		Model: null,
		oDataModel: null,
		step1ValidationFields: [],
		resourceBundle: null,
		lastDisabledCheckbox: null,
		isFirstTime: true,
		steps: ["basicInfo", "educHistory", "empHistory", "attachments"],

		onInit: function () {
			this.selectedDest = [];
		},

		handleIconTabBarSelect: function (oEvent) {
			var pageKey = this.steps[this.currentPage];
			oEvent.getSource().setSelectedKey(pageKey);
			return false;
		},

		next: function (evt) {

			/*this.currentPage++;
			var pageKey = this.steps[this.currentPage];
			//this.goTo(this.steps[this.currentPage]);
			this.getView().byId("handleTabBar").setSelectedKey(pageKey);*/

			if (this.currentPage < (this.steps.length - 1)) {

				this.currentPage++;
				var target = "";
				var navigation = this.byId("steps");
				var pageKey = this.steps[this.currentPage];

				if (pageKey === "educHistory") {
					this.getView().byId("backBtn").setVisible(true);
					target = "educHistoryPage";

				} else if (pageKey === "empHistory") {
					target = "empHistoryPage";

				} else if (pageKey === "attachments") {
					target = "attachmentsPage";
					this.getView().byId("submitBtn").setVisible(true);
					this.getView().byId("nextBtn").setVisible(false);
					this.getView().byId("backBtn").setVisible(true);
				}

				if (target) {
					navigation.to(this.byId(target));
					this.getView().byId("handleTabBar").setSelectedKey(pageKey);
				}
			} else {
				this.currentPage--;
				return;
			}

		},
		back: function (evt) {

			this.getView().byId("submitBtn").setVisible(false);
			this.getView().byId("nextBtn").setVisible(true);
			//on clicking previous button

			if (this.currentPage > 0) {
				this.currentPage--;
				var target = "";
				var navigation = this.byId("steps");
				var pageKey = this.steps[this.currentPage];

				if (pageKey === "educHistory") {
					target = "educHistoryPage";

				} else if (pageKey === "empHistory") {
					target = "empHistoryPage";

				} else {
					target = "basicInfoPage";

				}
			}

			if (target === "basicInfoPage") {
				this.getView().byId("submitBtn").setVisible(false);
				this.getView().byId("nextBtn").setVisible(true);
				this.getView().byId("backBtn").setVisible(false);
			}

			//navigating to target page
			if (target) {
				navigation.to(this.byId(target));
				this.getView().byId("handleTabBar").setSelectedKey(pageKey);

			} else {
				this.currentPage++;
				return;
			}
		},
		loadItems: function (oEvent) {
			//	alert();
			var selectedValue = oEvent.getParameters().newValue;
			this.selectedDest.push(selectedValue);

			var oViewModel = new JSONModel({
				myName: this.selectedDest
			});
			this.getView().setModel(oViewModel, "view");
		},

		onAddEdu: function () {
			//on Adding a new record 
			this.getView().byId("idEduRecordTable").setVisible(false);
			this.getView().byId("EducationRecordForm").setVisible(true);
		},
		onSaveEdu: function () {
			//	alert();

			//retrieving values from the form
			var instName = this.getView().byId("idInstuteName").getValue();
			var Language = this.getView().byId("idLang").getValue();
			var StudyDate = this.getView().byId("idStudyDate").getValue();
			var GradDate = this.getView().byId("idGardDate").getValue();

			//inserting above values to the table
			var oTable = this.getView().byId("idEduRecordTable");

			/*sap.ui.getCore().byId(this.createId("idCol1")).setText(instName);
			sap.ui.getCore().byId(this.createId("idCol2")).setText(Language);
			sap.ui.getCore().byId(this.createId("idCol3")).setText(StudyDate);
			sap.ui.getCore().byId(this.createId("idCol4")).setText(GradDate);
*/
			var columnListItemNewLine = new ColumnListItem({
				cells: [
					new sap.m.Text({
						text: instName
					}),
					new sap.m.Text({
						text: Language
					}),
					new sap.m.Text({
						text: StudyDate
					}),
					new sap.m.Text({
						text: GradDate
					})
				]
			});
			oTable.addItem(columnListItemNewLine);

			this.getView().byId("idEduRecordTable").setVisible(true);
			this.getView().byId("EducationRecordForm").setVisible(false);
			this.getView().byId("idCancelIcon_Edu").setVisible(true);
			this.getView().byId("idEditIcon_Edu").setVisible(true);
		},
		onCancelEdu: function () {

			//on cancelling form
			this.getView().byId("idEduRecordTable").setVisible(true);
			this.getView().byId("EducationRecordForm").setVisible(false);

		},
		onEditEdu: function (oEvent) {
			var oTable = this.getView().byId("idEduRecordTable");
			var length = this.getView().byId("idEduRecordTable").getSelectedItems().length;
			if (length > 1)
				sap.m.MessageToast.show("please select only one record");
			else if (length < 1)
				sap.m.MessageToast.show("please select a record");
			else {
				this.getView().byId("idEduRecordTable").setVisible(false);
				this.getView().byId("EducationRecordForm").setVisible(true);
				this.getView().byId("idEduEditBtn").setVisible(true);
				this.getView().byId("idEduSaveBtn").setVisible(false);

				var Name = oTable.getSelectedItems()[0].getCells()[0].getText();
				var Lang = oTable.getSelectedItems()[0].getCells()[1].getText();
				var StudyDate = oTable.getSelectedItems()[0].getCells()[2].getText();
				var GradDate = oTable.getSelectedItems()[0].getCells()[3].getText();

				//this.getView().byId("EducationRecordForm").setValue(newName);
				this.getView().byId("idInstuteName").setValue(Name);
				this.getView().byId("idLang").setValue(Lang);
				this.getView().byId("idStudyDate").setValue(StudyDate);
				this.getView().byId("idGardDate").setValue(GradDate);
			}
		},
		onUpdateEdu: function () {
			//	alert();
			var newinstName = this.getView().byId("idInstuteName").getValue();
			var newLanguage = this.getView().byId("idLang").getValue();
			var newStudyDate = this.getView().byId("idStudyDate").getValue();
			var newGradDate = this.getView().byId("idGardDate").getValue();

			this.getView().byId("idEduRecordTable").getSelectedItems()[0].getCells()[0].setText(newinstName);
			this.getView().byId("idEduRecordTable").getSelectedItems()[0].getCells()[1].setText(newLanguage);
			this.getView().byId("idEduRecordTable").getSelectedItems()[0].getCells()[2].setText(newStudyDate);
			this.getView().byId("idEduRecordTable").getSelectedItems()[0].getCells()[3].setText(newGradDate);

			this.getView().byId("idEduRecordTable").setVisible(true);
			this.getView().byId("EducationRecordForm").setVisible(false);
			this.getView().byId("idEduEditBtn").setVisible(false);
			this.getView().byId("idEduSaveBtn").setVisible(true);

		},
		onDelEdu: function (oEvent) {
		
			var oTable = this.getView().byId("idEduRecordTable");
			var aSelectedItems = oTable.getSelectedItems();
			if (aSelectedItems.length < 1) {

				MessageBox.alert("Please select atleast one record");
			} else {
				for (var i = 0; i < aSelectedItems.length; i++) {
					oTable.removeItem(aSelectedItems[i]);
				}
				MessageToast.show("Record(s) deleted");
			}

		},

		onAddEmpRecord: function () {
			this.getView().byId("idEmpRecordTable").setVisible(false);
			this.getView().byId("idEmpRecordForm").setVisible(true);
		},

		onSaveEmpRecord: function () {
			//retrieving values from the form
			var OrgName = this.getView().byId("idOrgName").getValue();
			var Occupation = this.getView().byId("idOccupation").getValue();
			var Designation = this.getView().byId("idDesg").getValue();
			var Country = this.getView().byId("idEmpCountry").getSelectedItem();

			//inserting above values to the table
			var oTable = this.getView().byId("idEmpRecordTable");

			var columnListItemNewLine = new ColumnListItem({
				cells: [
					new sap.m.Text({
						text: OrgName
					}),
					new sap.m.Text({
						text: Occupation
					}),
					new sap.m.Text({
						text: Designation
					}),
					new sap.m.Text({
						text: Country
					})
				]
			});
			oTable.addItem(columnListItemNewLine);

			this.getView().byId("idEmpRecordTable").setVisible(true);
			this.getView().byId("idEmpRecordForm").setVisible(false);
			this.getView().byId("idCancelIcon_Emp").setVisible(true);
			this.getView().byId("idEditIcon_Emp").setVisible(true);
		},
		onAddAttachment: function (oEvent) {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("idAttachFragment", "sap.uisubmit_application.fragments.Add_attachment", this);
			}
			this._oDialog.setModel(this.getView().getModel());
			this._oDialog.open();
		},
		onSaveAttcahment: function (oEvent) {
			//	alert();
			var Category = sap.ui.getCore().byId("idAttachFragment--idDocCategory").getValue();
			var DocName = sap.ui.getCore().byId("idAttachFragment--idDocName").getValue();
			var fileURL = sap.ui.getCore().byId("idAttachFragment--idfileUploader").getValue();
			var oTable = this.getView().byId("idAttachmentTable");

			var columnListItemNewLine = new ColumnListItem({
				cells: [
					new sap.m.Text({
						text: Category
					}),
					new sap.m.Text({
						text: DocName
					}), new sap.m.Text({
						text: fileURL
					})
				]
			});

			oTable.addItem(columnListItemNewLine);
			//this.handleUploadPress();
			this._oDialog.close();
		},
		handleUploadPress: function (oEvent) {
			var oFileUploader = sap.ui.getCore().byId("idAttachFragment--idfileUploader");
			oFileUploader.upload();
		},
		handleUploadComplete: function (oEvent) {
			var sResponse = oEvent.getParameter("response");
			if (sResponse) {
				var sMsg = "";
				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				if (m[1] === "200") {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		}

	});
});